package com.example.proyectofinal;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import java.util.ArrayList;
import java.util.List;

public class VerEstadisticaFragment extends Fragment implements MatchAdapter.OnMatchClickListener {

    private RecyclerView recyclerView;
    private MatchAdapter adapter;
    private List<Match> matchList;
    ImageView imageArrowLeft;
    NavController navController;

    public VerEstadisticaFragment() {
        // Constructor vacío requerido por Fragment
    }

    @Override
    public void onMatchClick(int position) {
        // Navegar al fragmento EstadisticaPartido
        navController.navigate(R.id.estadisticaPartido);
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_ver_estadistica, container, false);
        navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment);
        imageArrowLeft = view.findViewById(R.id.imageArrowleft);
        recyclerView = view.findViewById(R.id.recyclerViewEstadisticas);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        imageArrowLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.menuPrincipal);
            }
        });
        // Obtener los datos para mostrar en el RecyclerView
        matchList = obtenerDatosParaMostrar();

        // Configurar y establecer el adaptador en el RecyclerView
        adapter = new MatchAdapter(matchList, getContext());
        adapter.setOnMatchClickListener(this);
        recyclerView.setAdapter(adapter);

        return view;
    }

    private List<Match> obtenerDatosParaMostrar() {
               List<Match> matchList = new ArrayList<>();
        matchList.add(new Match(R.drawable.img_image10, R.drawable.img_image11, "VS"));
        matchList.add(new Match(R.drawable.img_image12, R.drawable.img_image13, "VS"));
        matchList.add(new Match(R.drawable.img_image14, R.drawable.img_image15, "VS"));
        matchList.add(new Match(R.drawable.img_image16, R.drawable.img_image17, "VS"));
        matchList.add(new Match(R.drawable.img_image18, R.drawable.img_image19, "VS"));
        matchList.add(new Match(R.drawable.img_image22, R.drawable.img_image21, "VS"));

        return matchList;
    }
}
