package com.example.proyectofinal;

public class Match {
    private int imageTeam1;
    private int imageTeam2;
    private String matchText;

    public Match(int imageTeam1, int imageTeam2, String matchText) {
        this.imageTeam1 = imageTeam1;
        this.imageTeam2 = imageTeam2;
        this.matchText = matchText;
    }

    public int getImageTeam1() {
        return imageTeam1;
    }

    public void setImageTeam1(int imageTeam1) {
        this.imageTeam1 = imageTeam1;
    }

    public int getImageTeam2() {
        return imageTeam2;
    }

    public void setImageTeam2(int imageTeam2) {
        this.imageTeam2 = imageTeam2;
    }

    public String getMatchText() {
        return matchText;
    }

    public void setMatchText(String matchText) {
        this.matchText = matchText;
    }
}
