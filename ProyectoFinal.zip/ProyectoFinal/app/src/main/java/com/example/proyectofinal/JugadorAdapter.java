package com.example.proyectofinal;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class JugadorAdapter extends RecyclerView.Adapter<JugadorAdapter.JugadorViewHolder> {

    private List<Jugador> jugadores;
    private Context context;

    public JugadorAdapter(Context context, List<Jugador> jugadores) {
        this.context = context;
        this.jugadores = jugadores;
    }

    @NonNull
    @Override
    public JugadorViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.fragment_list_items_jugadores, parent, false);
        return new JugadorViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull JugadorViewHolder holder, int position) {
        Jugador jugador = jugadores.get(position);
        holder.textNombre.setText(jugador.getNombre());
        holder.textApellido.setText(jugador.getApellido());
        holder.textDorsal.setText(jugador.getDorsal());
        holder.textPosicion.setText(jugador.getPosicion());
    }

    @Override
    public int getItemCount() {
        return jugadores.size();
    }

    public static class JugadorViewHolder extends RecyclerView.ViewHolder {
        TextView textNombre, textApellido, textDorsal, textPosicion;

        public JugadorViewHolder(@NonNull View itemView) {
            super(itemView);
            textNombre = itemView.findViewById(R.id.textNombre);
            textApellido = itemView.findViewById(R.id.textApellido);
            textDorsal = itemView.findViewById(R.id.textDorsal);
            textPosicion = itemView.findViewById(R.id.textPosicion);
        }
    }
}
