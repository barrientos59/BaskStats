package com.example.proyectofinal;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import com.example.proyectofinal.MatchAdapter.OnMatchClickListener;


public class MatchAdapter extends RecyclerView.Adapter<MatchAdapter.MatchViewHolder> {

    private List<Match> matchList;
    private Context context;
    private OnMatchClickListener listener;

    public MatchAdapter(List<Match> matchList, Context context) {
        this.matchList = matchList;
        this.context = context;
    }
    public interface OnMatchClickListener {
        void onMatchClick(int position);
    }

    @NonNull
    @Override
    public MatchViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_match, parent, false);
        return new MatchViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MatchViewHolder holder, int position) {
        Match match = matchList.get(position);
        holder.imageTeam1.setImageResource(match.getImageTeam1());
        holder.imageTeam2.setImageResource(match.getImageTeam2());
        holder.textMatch.setText(match.getMatchText());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onMatchClick(position);
                }
            }
        });
    }
    public void setOnMatchClickListener(OnMatchClickListener listener) {
        this.listener = listener;
    }
    @Override
    public int getItemCount() {
        return matchList.size();
    }

    public static class MatchViewHolder extends RecyclerView.ViewHolder {
        ImageView imageTeam1, imageTeam2;
        TextView textMatch;

        public MatchViewHolder(@NonNull View itemView) {
            super(itemView);
            imageTeam1 = itemView.findViewById(R.id.imageTeam1);
            imageTeam2 = itemView.findViewById(R.id.imageTeam2);
            textMatch = itemView.findViewById(R.id.textMatch);
        }
    }
}
