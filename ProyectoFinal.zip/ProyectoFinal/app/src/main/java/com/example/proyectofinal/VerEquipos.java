// VerEquipos.java
package com.example.proyectofinal;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class VerEquipos extends Fragment implements TeamAdapter.OnItemClickListener {

    private RecyclerView recyclerView;
    private TeamAdapter adapter;
    private ImageView imageArrowLeft;
    NavController navController;
    public VerEquipos() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_ver_equipos, container, false);
        navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment);

        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        List<Team> teamList = generateTeamList();
        adapter = new TeamAdapter(getActivity(), teamList);
        recyclerView.setAdapter(adapter);
        adapter.setOnItemClickListener(this);


        imageArrowLeft = view.findViewById(R.id.imageArrowleft);
        imageArrowLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigateUp(); // Regresar al fragmento anterior
            }
        });
        return view;
    }

    private List<Team> generateTeamList() {
        List<Team> teamList = new ArrayList<>();
        // Aquí agregarías tus equipos con sus nombres y fotos
        teamList.add(new Team("Equipo 1", R.drawable.img_image10));
        teamList.add(new Team("Equipo 2", R.drawable.img_image11));
        teamList.add(new Team("Equipo 3", R.drawable.img_image12));
        teamList.add(new Team("Equipo 4", R.drawable.img_image13));
        teamList.add(new Team("Equipo 5", R.drawable.img_image14));
        teamList.add(new Team("Equipo 6", R.drawable.img_image15));
        teamList.add(new Team("Equipo 7", R.drawable.img_image16));
        teamList.add(new Team("Equipo 8", R.drawable.img_image17));
        teamList.add(new Team("Equipo 9", R.drawable.img_image18));
        // Agregar más equipos si es necesario
        return teamList;
    }

    @Override
    public void onItemClick(int position) {
    navController.navigate(R.id.listaJugadoresEquipo);

    }
}
