package com.example.proyectofinal;

public class Player {
    private String playerName;
    private int points;
    private int assists;
    private int rebounds;
    private int blocks;
    private int turnovers;
    private int fouls;

    public Player(String playerName, int points, int assists, int rebounds, int blocks, int turnovers, int fouls) {
        this.playerName = playerName;
        this.points = points;
        this.assists = assists;
        this.rebounds = rebounds;
        this.blocks = blocks;
        this.turnovers = turnovers;
        this.fouls = fouls;
    }

    public String getPlayerName() {
        return playerName;
    }

    public int getPoints() {
        return points;
    }

    public int getAssists() {
        return assists;
    }

    public int getRebounds() {
        return rebounds;
    }

    public int getBlocks() {
        return blocks;
    }

    public int getTurnovers() {
        return turnovers;
    }

    public int getFouls() {
        return fouls;
    }
}

