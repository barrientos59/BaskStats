package com.example.proyectofinal;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PlayerAdapter extends RecyclerView.Adapter<PlayerAdapter.PlayerViewHolder> {
    private List<Player> players;

    public PlayerAdapter(List<Player> players) {
        this.players = players;
    }

    @NonNull
    @Override
    public PlayerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_player, parent, false);
        return new PlayerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PlayerViewHolder holder, int position) {
        Player player = players.get(position);
        holder.textViewPlayerName.setText(player.getPlayerName());
        holder.textViewPoints.setText("Puntos: " + player.getPoints());
        holder.textViewAssists.setText("Asistencias: " + player.getAssists());
        holder.textViewRebounds.setText("Rebotes: " + player.getRebounds());
        holder.textViewBlocks.setText("Tapones: " + player.getBlocks());
        holder.textViewTurnovers.setText("Pérdidas: " + player.getTurnovers());
        holder.textViewFouls.setText("Faltas: " + player.getFouls());
    }

    @Override
    public int getItemCount() {
        return players.size();
    }

    public static class PlayerViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewPlayerName;
        public TextView textViewPoints;
        public TextView textViewAssists;
        public TextView textViewRebounds;
        public TextView textViewBlocks;
        public TextView textViewTurnovers;
        public TextView textViewFouls;

        public PlayerViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewPlayerName = itemView.findViewById(R.id.textViewPlayerName);
            textViewPoints = itemView.findViewById(R.id.textViewPoints);
            textViewAssists = itemView.findViewById(R.id.textViewAssists);
            textViewRebounds = itemView.findViewById(R.id.textViewRebounds);
            textViewBlocks = itemView.findViewById(R.id.textViewBlocks);
            textViewTurnovers = itemView.findViewById(R.id.textViewTurnovers);
            textViewFouls = itemView.findViewById(R.id.textViewFouls);
        }
    }
}
