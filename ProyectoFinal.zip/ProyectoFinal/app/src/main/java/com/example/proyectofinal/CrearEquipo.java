package com.example.proyectofinal;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class CrearEquipo extends Fragment {
    NavController navController;
    Button crearequipo;
    ImageView imageArrowLeft;
    EditText UbiCrearEquipo;
    EditText LogoCrearEquipo;
    private static final int PICK_IMAGE = 1;

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_crear_equipo, container, false);
        navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment);
        imageArrowLeft = view.findViewById(R.id.imageArrowleft);
        UbiCrearEquipo = view.findViewById(R.id.UbiCrearEquipo);
        LogoCrearEquipo = view.findViewById(R.id.LogoCrearEquipo);
        crearequipo = view.findViewById(R.id.btnCrear);

        crearequipo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.listaJugadoresEquipo);
            }
        });

        imageArrowLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.menuPrincipal);
            }
        });

        UbiCrearEquipo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.mapa);
            }
        });

        LogoCrearEquipo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });

        return view;
    }

    private void openGallery() {
        Intent gallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(gallery, PICK_IMAGE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == Activity.RESULT_OK && data != null) {
            // La imagen seleccionada está en el intent 'data', puedes manejarla como quieras
            // Aquí puedes obtener la URI de la imagen seleccionada si necesitas guardarla o procesarla
            // Por ahora, no necesitas hacer nada aquí si solo quieres volver al fragmento sin cargar la imagen
        }
    }
}
