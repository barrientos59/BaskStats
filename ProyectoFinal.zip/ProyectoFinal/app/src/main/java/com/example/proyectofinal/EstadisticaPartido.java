package com.example.proyectofinal;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class EstadisticaPartido extends Fragment {

    private RecyclerView recyclerViewEquipoA;
    private RecyclerView recyclerViewEquipoB;
    private PlayerAdapter adapterEquipoA;
    private PlayerAdapter adapterEquipoB;
    NavController navController;
    ImageView imageArrowLeft;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_estadistica_partido, container, false);

        // Obtener referencias a los RecyclerViews
        recyclerViewEquipoA = rootView.findViewById(R.id.recyclerViewEquipoA);
        recyclerViewEquipoB = rootView.findViewById(R.id.recyclerViewEquipoB);

        // Configurar LinearLayoutManager para cada RecyclerView
        recyclerViewEquipoA.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerViewEquipoB.setLayoutManager(new LinearLayoutManager(getActivity()));

        // Configurar adaptadores para cada RecyclerView
        adapterEquipoA = new PlayerAdapter(getPlayersForEquipoA()); // Implementa este método para obtener los datos del equipo A
        adapterEquipoB = new PlayerAdapter(getPlayersForEquipoB()); // Implementa este método para obtener los datos del equipo B

        // Establecer adaptadores en los RecyclerViews
        recyclerViewEquipoA.setAdapter(adapterEquipoA);
        recyclerViewEquipoB.setAdapter(adapterEquipoB);
        navController = Navigation.findNavController(requireActivity(), R.id.nav_host_fragment);
        imageArrowLeft = rootView.findViewById(R.id.imageArrowleft);
        imageArrowLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigateUp(); // Regresar al fragmento anterior
            }
        });
        return rootView;
    }

    // Método para obtener los datos de los jugadores del equipo A
    private List<Player> getPlayersForEquipoA() {
        // Implementa este método para obtener los datos de los jugadores del equipo A
        // Puedes obtener estos datos de cualquier fuente de datos, como una lista estática o una base de datos
        List<Player> players = new ArrayList<>();
        // Agrega jugadores a la lista
        players.add(new Player("1", 10, 5, 8, 2, 3, 4));
        players.add(new Player("2", 8, 3, 6, 1, 2, 2));
        players.add(new Player("3", 10, 5, 8, 2, 3, 4));
        players.add(new Player("4", 8, 3, 6, 1, 2, 2));
        players.add(new Player("5", 10, 5, 8, 2, 3, 4));
        players.add(new Player("6", 8, 3, 6, 1, 2, 2));

        return players;
    }

    // Método para obtener los datos de los jugadores del equipo B (similar al método getPlayersForEquipoA())
    private List<Player> getPlayersForEquipoB() {
        // Implementa este método para obtener los datos de los jugadores del equipo B
        // Similar al método getPlayersForEquipoA()
        // Por ejemplo:
        List<Player> players = new ArrayList<>();
        players.add(new Player("1", 10, 5, 8, 2, 3, 4));
        players.add(new Player("2", 8, 3, 6, 1, 2, 2));
        players.add(new Player("3", 10, 5, 8, 2, 3, 4));
        players.add(new Player("4", 8, 3, 6, 1, 2, 2));
        players.add(new Player("5", 10, 5, 8, 2, 3, 4));
        players.add(new Player("6", 8, 3, 6, 1, 2, 2));
        return players;
    }
}
