package com.example.proyectofinal;
public class Jugador {
    private String nombre;
    private String apellido;
    private String dorsal;
    private String posicion;

    public Jugador(String nombre, String apellido, String dorsal, String posicion) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.dorsal = dorsal;
        this.posicion = posicion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getDorsal() {
        return dorsal;
    }

    public String getPosicion() {
        return posicion;
    }
}

